/**
 * 
 */
package com.mims.swing.ctrl;

import java.awt.Graphics;

import javax.swing.JList;
import javax.swing.border.Border;

/**
 * ����:.
 * <p>
 * 
 * @author ����
 * 
 * @Date: 2011-8-24
 * 
 */
public class JFList extends JList
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8736062719414731659L;

	private final String uiClassID = "JFListUI";

	public String getUIClassID()
	{
		return uiClassID;
	}

}
