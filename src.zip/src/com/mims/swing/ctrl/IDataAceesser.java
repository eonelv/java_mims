/**
 * 
 */
package com.mims.swing.ctrl;

/**
 * ����:.<p>
 *
 * @author ���� 
 *
 * @Date: 2011-9-12
 * 
 */
public interface IDataAceesser
{
	public void setUserObject(Object obj);
	
	public Object getUserObject();
}
