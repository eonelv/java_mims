package com.mims.pattern.adapter;

public class OtherCircle implements ICircle {

	public void paint() {
		System.out.println("Draw Circle.");
	}

}
