package com.mims.pattern.adapter;

public class Line implements IShape {

	public void draw() {
		System.out.println("Draw Line.");
	}

}
