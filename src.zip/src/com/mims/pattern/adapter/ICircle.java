package com.mims.pattern.adapter;

public interface ICircle {
	public void paint();
}
