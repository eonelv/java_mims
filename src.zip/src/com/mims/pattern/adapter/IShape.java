package com.mims.pattern.adapter;

public interface IShape {
	public void draw();
}
