package com.mims.pattern.strategy;

public interface IStrategy {
	public void performace();
}
