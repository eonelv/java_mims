package com.mims.pattern.strategy;

public class StrategyB implements IStrategy {

	public void performace() {
		System.out.println("Strategy B. ");
	}

}
