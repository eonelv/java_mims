package com.mims.pattern.strategy;

public class StrategyA implements IStrategy {

	public void performace() {
		System.out.println("Strategy A. ");
	}

}
