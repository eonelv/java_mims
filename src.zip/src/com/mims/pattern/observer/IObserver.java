package com.mims.pattern.observer;

/**
 * 
 * ����:.<p>
 *
 * @auther ����
 * @Date: 2010-12-6
 *
 */
public interface IObserver {
	public void change();
}
