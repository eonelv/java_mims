/**
 * 
 */
package com.mims.app.aim;

/**
 * ����:.<p>
 *
 * @author ���� 
 *
 * @Date: 2011-7-22
 * 
 */
public interface AimConst
{
	public static String KEY_TABLE = "\t";
	
	public static String KEY_ENTER = "\r\n";
}
