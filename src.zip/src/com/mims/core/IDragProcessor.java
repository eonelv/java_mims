package com.mims.core;

import java.io.File;
import java.util.List;

public interface IDragProcessor 
{
	void processDrop(List<File> files);
}
