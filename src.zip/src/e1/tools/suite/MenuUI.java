package e1.tools.suite;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JComponent;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import com.mims.app.aim.AimProcessUI;
import com.mims.app.aim.TreeNodeInfo;
import com.mims.app.test.TblTestUI;
import com.mims.core.CoreUI;
import com.mims.core.IUIHelper;
import com.mims.core.UIFactory;
import com.mims.core.log.LogSystem;
import com.mims.swing.ctrl.JFTabbedPaneManager;
import com.mims.swing.ctrl.JFTree;
import com.mims.swing.ctrl.SwingConst;
import com.mims.swing.layout.FlexLayout;
import com.mims.swing.layout.LayoutProperty;
import com.mims.swing.look.JFBorders;

public class MenuUI extends CoreUI
{
	private JTree menuTree = null;
	
	private MouseListener treeClickListerner = null;
	
	private Map<String, DefaultMutableTreeNode> menuInfos;
	public MenuUI(Map uiContext)
	{
		this(uiContext, null);
	}
	
	public MenuUI(Map uiContext, String title)
	{
		super(uiContext, title);
		try {
			initCtrl();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		initAction();
		setSize(900, 600);
		setBackground(SwingConst.MAIN_PANEL_BACKGROUND);
	}
	
	private void initCtrl() throws URISyntaxException, IOException
	{		
		setLayout(new FlexLayout());
		putClientProperty(LayoutProperty.LAYOUT_PARENT_PROPERTY,
				new LayoutProperty(0, 0, 900, 600));
		
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");
		menuTree = new JFTree(root);
		menuTree.setRootVisible(false);
		menuTree.setBorder(new JFBorders.TextFieldBorder());
		
		loadMenus();
		
		DefaultTreeModel model = (DefaultTreeModel)menuTree.getModel();
		
		Iterator<String> it = menuInfos.keySet().iterator();
		String key;
		DefaultMutableTreeNode treeNode = null;
		DefaultMutableTreeNode parentTreeNode = null;
		TreeNodeInfo treeNodeInfo = null;
		while (it.hasNext())
		{
			key = it.next();
			treeNode = menuInfos.get(key);
			treeNodeInfo = (TreeNodeInfo)treeNode.getUserObject();
			parentTreeNode = menuInfos.get(treeNodeInfo.getParentID());
			if (parentTreeNode == null)
			{
				model.insertNodeInto(treeNode, root, root.getChildCount());
			}
			else
			{
				parentTreeNode.insert(treeNode, parentTreeNode.getChildCount());
			}
		}

		TreeNode[] tempNodes = model.getPathToRoot(treeNode);   
        TreePath path = new TreePath(tempNodes);   
        menuTree.scrollPathToVisible(path);
        menuTree.putClientProperty(LayoutProperty.LAYOUT_CHILD_PROPERTY,
				new LayoutProperty(10, 10, 300, 580, LayoutProperty.TOP | LayoutProperty.LEFT 
						| LayoutProperty.BOTTOM));
        menuTree.setBackground(getBackground());

        add(menuTree);
	}
	
	private void loadMenus() throws URISyntaxException, IOException
	{
		menuInfos = new HashMap<String, DefaultMutableTreeNode>();
		
		URL url = MenuUI.class.getClassLoader().getResource("e1/tools/suite/menu.properties");
		File file = new File(url.toURI());
		String line = null;
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(file), "utf-8"));
		
		String[] menuInfo;
		DefaultMutableTreeNode treeNode = null;
		TreeNodeInfo node = null;
		while ((line = reader.readLine()) != null) 
		{
			if (line.startsWith("#"))
			{
				continue;
			}
			menuInfo = line.split("-");
			treeNode = new DefaultMutableTreeNode();
			node = new TreeNodeInfo();
			node.setID(menuInfo[0]);
			node.setParentID(menuInfo[1]);
			
			node.setName(menuInfo[2]);
			node.setUiName(menuInfo[3]);
			node.setClassName(menuInfo[4]);
			node.setModel(Integer.parseInt(menuInfo[5]));
			treeNode.setUserObject(node);
			
			menuInfos.put(node.getID(), treeNode);
		}
	}
	
	private void initAction()
	{
		treeClickListerner = new MouseAdapter()
		{
			
			public void mouseClicked(MouseEvent e) {
				int count = e.getClickCount();
				if (count == 2)
				{
					DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode)menuTree.getLastSelectedPathComponent();
					TreeNodeInfo menuInfo = (TreeNodeInfo)treeNode.getUserObject();
					if (menuInfo.getClassName() != null)
					{
						CoreUI panel = (CoreUI)JFTabbedPaneManager.getManager().getOpenedTabs().get(menuInfo.getClassName());
						if (panel == null)
						{
							if (menuInfo.getModel() == IUIHelper.UIMODEL_NEWTAB)
							{
								MenuUI.this.getUiContext().put("UIParam", menuInfo.getUiParam());
								panel = (CoreUI)UIFactory.getUI(menuInfo.getClassName(), IUIHelper.UIMODEL_NEWTAB, 
										MenuUI.this.getUiContext(), menuInfo.getUiName(),MenuUI.this);
								if (panel == null)
								{
									return;
								}
								panel.setMainUI(MenuUI.this);
								panel.registMain(frame);
								
								frame.getMainTablePane().addTab(panel.getTitle(), panel);
								JFTabbedPaneManager.getManager().getOpenedTabs().put(menuInfo.getClassName(), panel);

								frame.getMainTablePane().setSelectedComponent(panel);
							}
							else
							{
								IUIHelper ui = UIFactory.getUI(menuInfo.getClassName(), menuInfo.getModel(),
										MenuUI.this.getUiContext(),MenuUI.this);
								ui.showUI();
							}
						}
						else
						{
							frame.getMainTablePane().setSelectedComponent(panel);
						}
					}
				}
			}
		};
		menuTree.addMouseListener(treeClickListerner);
	}
	public JComponent getUIObject()
	{
		return this;
	}
	
	public String getTitle()
	{
		return "EONE Tool Suite";
	}
}
