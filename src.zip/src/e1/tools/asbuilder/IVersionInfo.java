package e1.tools.asbuilder;

public class IVersionInfo 
{

}
