/*    */ package e1.tools.asbuilder;
/*    */ 
/*    */ import e1.tools.asbuilder.utils.FileUtils;
/*    */ 
/*    */ public class CreateVersion
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 14 */     FileUtils.updateVersion(args[0], 1);
/*    */   }
/*    */ }