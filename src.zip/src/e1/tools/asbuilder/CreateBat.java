/*    */ package e1.tools.asbuilder;
/*    */ 
/*    */ import e1.tools.asbuilder.utils.FileUtils;
/*    */ 
/*    */ public class CreateBat
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 13 */     FileUtils.createBat(args[0], args[1]);
/*    */   }
/*    */ }

/* Location:           C:\Users\lv\Desktop\java\e1asbuilder_utils.jar
 * Qualified Name:     e1.tools.asbuilder.CreateBat
 * JD-Core Version:    0.6.0
 */