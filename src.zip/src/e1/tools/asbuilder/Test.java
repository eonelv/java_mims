package e1.tools.asbuilder;

import java.io.File;

import net.sf.json.JSONObject;
import e1.tools.asbuilder.utils.EJSON;
import e1.tools.utils.FileCopyer;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String name = "a.tamf";
		int index = name.lastIndexOf('.');
		System.out.println(name.substring(index));
	}

}
