package e1.tools.lzma.sevenzip;

public interface ICodeProgress
{
	public void SetProgress(long inSize, long outSize);
}